import org.junit.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class RedBlackTreeTest {
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;
    private RedBlackTree<Integer> rbt;

    @Before
    public void initTest() {
        rbt = new RedBlackTree<Integer>();
        System.setOut(new PrintStream(outContent));
    }

    @Test
    public void nullTest() {
        rbt.add(null);
        rbt.printColorTree();
        assertEquals("\n", outContent.toString());
    }

    @Test
    public void nullListTest() {
        List<Integer> list = new ArrayList<Integer>();

        rbt.add(null);
        assertEquals(list, rbt.listFromTree());
    }

    @Test
    public void emptyTest() {
        rbt.printColorTree();
        assertEquals("\n", outContent.toString());
    }

    @Test
    public void emptyListTest() {
        List<Integer> list = new ArrayList<Integer>();
        assertEquals(list, rbt.listFromTree());
    }

    @Test
    public void oneNodeTest() {
        rbt.add(1);
        rbt.printColorTree();
        assertEquals("B_1 \n", outContent.toString());
    }

    @Test
    public void oneNodeListTest() {
        List<Integer> list = new ArrayList<Integer>();
        list.add(1);

        rbt.add(1);
        assertEquals(list, rbt.listFromTree());
    }

    @Test
    public void twoIncreasingNodeTest() {
        rbt.add(1);
        rbt.add(2);
        rbt.printColorTree();
        assertEquals("B_1 R_2 \n", outContent.toString());
    }

    @Test
    public void twoIncreasingNodeListTest() {
        Integer integerArray[] = {1, 2};
        List<Integer> list = new ArrayList<Integer>(Arrays.asList(integerArray));

        rbt.add(1);
        rbt.add(2);
        assertEquals(list, rbt.listFromTree());
    }

    @Test
    public void threeIncreasingNodeForOneLeftRotateTest() {
        rbt.add(1);
        rbt.add(2);
        rbt.add(3); //left rotate
        rbt.printColorTree();
        assertEquals("R_1 B_2 R_3 \n", outContent.toString());
    }

    @Test
    public void threeIncreasingNodeForOneLeftRotateListTest() {
        Integer integerArray[] = {1, 2, 3};
        List<Integer> list = new ArrayList<Integer>(Arrays.asList(integerArray));

        rbt.add(1);
        rbt.add(2);
        rbt.add(3); //left rotate
        assertEquals(list, rbt.listFromTree());
    }

    @Test
    public void twoDecreasingNodeTest() {
        rbt.add(3);
        rbt.add(2);
        rbt.printColorTree();
        assertEquals("R_2 B_3 \n", outContent.toString());
    }

    @Test
    public void twoDecreasingNodeListTest() {
        Integer integerArray[] = {2, 3};
        List<Integer> list = new ArrayList<Integer>(Arrays.asList(integerArray));

        rbt.add(3);
        rbt.add(2);
        assertEquals(list, rbt.listFromTree());
    }

    @Test
    public void threeDecreasingNodeForOneRightRotateTest() {
        rbt.add(3);
        rbt.add(2);
        rbt.add(1); //right rotate
        rbt.printColorTree();
        assertEquals("R_1 B_2 R_3 \n", outContent.toString());
    }

    @Test
    public void threeDecreasingNodeForOneRightRotateListTest() {
        Integer integerArray[] = {1, 2, 3};
        List<Integer> list = new ArrayList<Integer>(Arrays.asList(integerArray));

        rbt.add(3);
        rbt.add(2);
        rbt.add(1); //right rotate
        assertEquals(list, rbt.listFromTree());
    }

    @Test
    public void fourRightNodeWithChangeColorTest() {
        rbt.add(0);
        rbt.add(0);
        rbt.add(0); //left rotate
        rbt.add(0); //black grand, red dad, red uncle -> black grand, black dad, black uncle
        rbt.printColorTree();
        assertEquals("B_0 B_0 B_0 R_0 \n", outContent.toString());
    }

    @Test
    public void fourRightNodeWithChangeColorListTest() {
        Integer integerArray[] = {0, 0, 0, 0};
        List<Integer> list = new ArrayList<Integer>(Arrays.asList(integerArray));

        rbt.add(0);
        rbt.add(0);
        rbt.add(0); //left rotate
        rbt.add(0); //black grand, red dad, red uncle -> black grand, black dad, black uncle
        assertEquals(list, rbt.listFromTree());
    }

    @Test
    public void fourLeftNodeWithChangeColorTest() {
        rbt.add(9);
        rbt.add(7);
        rbt.add(8); //left rotate and right rotate
        rbt.add(7); //black grand, red dad, red uncle -> black grand, black dad, black uncle
        rbt.printColorTree();
        assertEquals("B_7 R_7 B_8 B_9 \n", outContent.toString());
    }

    @Test
    public void fourLeftNodeWithChangeColorListTest() {
        Integer integerArray[] = {7, 7, 8, 9};
        List<Integer> list = new ArrayList<Integer>(Arrays.asList(integerArray));

        rbt.add(9);
        rbt.add(7);
        rbt.add(8); //left rotate and right rotate
        rbt.add(7); //black grand, red dad, red uncle -> black grand, black dad, black uncle
        assertEquals(list, rbt.listFromTree());
    }

    @Test
    public void fiveIncreaseNodeWithChangeColorTest() {
        rbt.add(4);
        rbt.add(4);
        rbt.add(4); //left rotate
        rbt.add(5); //black grand, red dad, red uncle -> black grand, black dad, black uncle
        rbt.add(4); //right rotate and left rotate
        rbt.printColorTree();
        assertEquals("B_4 B_4 R_4 B_4 R_5 \n", outContent.toString());
    }

    @Test
    public void fiveIncreaseNodeWithChangeColorListTest() {
        Integer integerArray[] = {4, 4, 4, 4, 5};
        List<Integer> list = new ArrayList<Integer>(Arrays.asList(integerArray));

        rbt.add(4);
        rbt.add(4);
        rbt.add(4); //left rotate
        rbt.add(5); //black grand, red dad, red uncle -> black grand, black dad, black uncle
        rbt.add(4); //right rotate and left rotate
        assertEquals(list, rbt.listFromTree());
    }

    @Test
    public void fiveEqualNodeWithChangeColorTest() {
        rbt.add(4);
        rbt.add(4);
        rbt.add(4); //left rotate
        rbt.add(4); //black grand, red dad, red uncle -> black grand, black dad, black uncle
        rbt.add(4); //right rotate
        rbt.printColorTree();
        assertEquals("B_4 B_4 R_4 B_4 R_4 \n", outContent.toString());
    }

    @Test
    public void fiveEqualNodeWithChangeColorListTest() {
        Integer integerArray[] = {4, 4, 4, 4, 4};
        List<Integer> list = new ArrayList<Integer>(Arrays.asList(integerArray));

        rbt.add(4);
        rbt.add(4);
        rbt.add(4); //left rotate
        rbt.add(4); //black grand, red dad, red uncle -> black grand, black dad, black uncle
        rbt.add(4); //right rotate
        assertEquals(list, rbt.listFromTree());
    }

    @Test
    public void sevenNodeWithRightRotateAfterRootTest() {
        rbt.add(5);
        rbt.add(4);
        rbt.add(7);
        rbt.add(6); //black grand, red dad, red uncle -> black grand, black dad, black uncle
        rbt.add(8);
        rbt.add(6); //black grand, red dad, red uncle -> black grand, black dad, black uncle "B_4 B_5 B_6 R_6 R_7 B_8 "
        rbt.add(6); //right rotate and left rotate
        rbt.printColorTree();
        assertEquals("B_4 B_5 R_6 B_6 R_6 R_7 B_8 \n", outContent.toString());
    }

    @Test
    public void sevenNodeWithRightRotateAfterRootListTest() {
        Integer integerArray[] = {4, 5, 6, 6, 6, 7, 8};
        List<Integer> list = new ArrayList<Integer>(Arrays.asList(integerArray));

        rbt.add(5);
        rbt.add(4);
        rbt.add(7);
        rbt.add(6); //black grand, red dad, red uncle -> black grand, black dad, black uncle
        rbt.add(8);
        rbt.add(6); //black grand, red dad, red uncle -> black grand, black dad, black uncle "B_4 B_5 B_6 R_6 R_7 B_8 "
        rbt.add(6); //right rotate and left rotate
        assertEquals(list, rbt.listFromTree());
    }

    @Test
    public void eigthNodeChangeRootTest() {
        rbt.add(5);
        rbt.add(4);
        rbt.add(7);
        rbt.add(6); //black grand, red dad, red uncle -> black grand, black dad, black uncle
        rbt.add(8);
        rbt.add(6); //black grand, red dad, red uncle -> black grand, black dad, black uncle "B_4 B_5 B_6 R_6 R_7 B_8 "
        rbt.add(6); //right rotate and left rotate
        rbt.add(6); //right rotate and left rotate
        rbt.printColorTree();
        assertEquals("B_4 R_5 B_6 B_6 B_6 R_6 R_7 B_8 \n", outContent.toString());
    }

    @Test
    public void eigthNodeChangeRootListTest() {
        Integer integerArray[] = {4, 5, 6, 6, 6, 6, 7, 8};
        List<Integer> list = new ArrayList<Integer>(Arrays.asList(integerArray));

        rbt.add(5);
        rbt.add(4);
        rbt.add(7);
        rbt.add(6); //black grand, red dad, red uncle -> black grand, black dad, black uncle
        rbt.add(8);
        rbt.add(6); //black grand, red dad, red uncle -> black grand, black dad, black uncle "B_4 B_5 B_6 R_6 R_7 B_8 "
        rbt.add(6); //right rotate and left rotate
        rbt.add(6); //right rotate and left rotate
        assertEquals(list, rbt.listFromTree());
    }

    @After
    public void restoreStreams() {
        System.setOut(originalOut);
    }
}
